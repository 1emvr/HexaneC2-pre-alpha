local opts = { noremap = true, silent = true }
local term_opts = { silent = true }

-- Wrapper for keymaps
local function keymap (mode, binding, action)
    vim.api.nvim_set_keymap(mode, binding, action, opts)
end

-- Remap <Space> as leader key
keymap("", "<Space>", "<Nop>")
vim.g.mapleader = " "
vim.g.maplocalleader = " "

-- Modes
--   normal       = "n"
--   insert       = "i"
--   visual       = "v"
--   visual_block = "x"
--   term         = "t"
--   command      = "c"

-- Normal --
-- Window nav
keymap("n", "<C-h>", "<C-w>h")
keymap("n", "<C-j>", "<C-w>j")
keymap("n", "<C-k>", "<C-w>k")
keymap("n", "<C-l>", "<C-w>l")

-- Telescope
keymap("n", "<leader>e", ":Telescope file_browser<CR>")
keymap("n", "<leader>f", ":Telescope live_grep<CR>")

-- Resize with arrows
keymap("n", "<C-Up>",    ":resize +2<CR>")
keymap("n", "<C-Down>",  ":resize-2<CR>")
keymap("n", "<C-Left>",  ":vertical resize +2<CR>")
keymap("n", "<C-Right>", ":vertical resize -2<CR>")

-- Navigate buffers
keymap("n", "<S-l>", ":bnext<CR>")
keymap("n", "<S-h>", ":bprevious<CR>")

-- Insert --
-- Press jk fast to leave Insert
keymap("i", "jk", "<ESC>")

-- Visual --
-- Stay in indent mode
keymap("v", "<", "<gv")
keymap("v", ">", ">gv")

-- Move text up and down
keymap("v", "<A-j>", ":m .+1<CR>==")
keymap("v", "<A-k>", ":m .-2<CR>==")
keymap("v", "p", '"_dP')  -- Stop nvim from replacing clipboard with what you replace when pasting

-- Visual Block --
-- Move text up and down
keymap("x", "J",     ":move '>+1<CR>gv-gv")
keymap("x", "K",     ":move '<-2<CR>gv-gv")
keymap("x", "<A-j>", ":move '>+1<CR>gv-gv")
keymap("x", "<A-k>", ":move '<-2<CR>gv-gv")

-- Terminal --
-- Better terminal nav
keymap("t", "<C-h>", "<C-\\><C-N><C-w>h")
keymap("t", "<C-j>", "<C-\\><C-N><C-w>j")
keymap("t", "<C-k>", "<C-\\><C-N><C-w>k")
keymap("t", "<C-l>", "<C-\\><C-N><C-w>l")

