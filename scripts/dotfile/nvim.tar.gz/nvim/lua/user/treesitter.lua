local configs = require("nvim-treesitter.configs")
local project = require("project_nvim")

require("nvim-treesitter.install").prefer_git = true

configs.setup {
    ensure_installed = {"c", "cpp", "lua", "python"},
    sync_install = false,
    ignore_install = { "" }, -- List of parsers to ignore installing.
    highlight = {
        enable = true, -- false disables the extension.
        disable = { "" }, -- list of languages to be disabled.
        additional_vim_regex_highlighting = true,
    },
    indent = { enable = true, disable = { "yaml" } },
    -- Rainbow plugin
    rainbow = {
        enable = false, -- Seems inconsistent so disabled for now.
        disable = { "" }, -- List of lanauges to disable.
        extended_mode = true, -- Also highlight non bracket delimeters, e.g. html tags, boolean etc.
        max_file_lines = nil
    }
}

project.setup {
    scope_chdir = 'global',
    datapath = vim.fn.stdpath("data"),
    detection_methods = { "lsp", "pattern" },
    manual_mode = false,
    show_hidden = false,
    silent_chdir = true,
}

local function print_project_root()
    local root = require('project_nvim.project').get_project_root()
    if root then
        print("Current project root: " .. root)
    else
        print("No project root detected")
    end
end

vim.cmd([[autocmd BufEnter * lua print_project_root()]])
